def find_cheapest_ticket(file_path):
    with open( 'tickets.txt', 'r') as file:
        lines = file.readlines()

    if not lines:
        print("No tickets found in the file.")
        return

    cheapest_ticket = float('inf')
    cheapest_company = ""

    for line in lines:
        parts = line.strip().split()
        if len(parts) == 2:
            try:
                cost = int(parts[0])
                company = parts[1]

                if cost < cheapest_ticket:
                    cheapest_ticket = cost
                    cheapest_company = company

            except ValueError:
                print(f"Invalid format in line: {line}")

    if cheapest_company:
        print(f"The cheapest ticket is from {cheapest_company} with a cost of {cheapest_ticket}.")
    else:
        print("No valid tickets found in the file.")

# Replace 'tickets.txt' with the actual path to your file if it's located in a different directory.
find_cheapest_ticket('tickets.txt')
